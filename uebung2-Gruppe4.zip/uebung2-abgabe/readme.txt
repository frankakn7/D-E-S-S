Die Seite kann geserved werden mit `php artisan serve`

Folgende Dateien haben wir veraendert bzw hinzugefuegt:
- storage/app/vorlesungszeiten.json
- resources/views/welcome.blade.php
- app/Http/Controllers/ExamController.php
- routes/web.php
